import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("mega_ai.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    title TEXT,
    created_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    session_id TEXT,
    role TEXT,
    content TEXT,
    model TEXT,
    timestamp INTEGER,
    attachments TEXT,
    FOREIGN KEY(session_id) REFERENCES sessions(id)
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/sessions", (req, res) => {
    const sessions = db.prepare("SELECT * FROM sessions ORDER BY created_at DESC").all();
    res.json(sessions);
  });

  app.post("/api/sessions", (req, res) => {
    const { id, title } = req.body;
    db.prepare("INSERT INTO sessions (id, title, created_at) VALUES (?, ?, ?)").run(id, title, Date.now());
    res.json({ status: "ok" });
  });

  app.get("/api/messages/:sessionId", (req, res) => {
    const messages = db.prepare("SELECT * FROM messages WHERE session_id = ? ORDER BY timestamp ASC").all(req.params.sessionId);
    res.json(messages.map(m => ({
      ...m,
      attachments: JSON.parse(m.attachments || "[]")
    })));
  });

  app.post("/api/messages", (req, res) => {
    const { id, session_id, role, content, model, timestamp, attachments } = req.body;
    db.prepare(`
      INSERT INTO messages (id, session_id, role, content, model, timestamp, attachments)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, session_id, role, content, model, timestamp, JSON.stringify(attachments || []));
    res.json({ status: "ok" });
  });

  app.delete("/api/sessions/:id", (req, res) => {
    db.prepare("DELETE FROM messages WHERE session_id = ?").run(req.params.id);
    db.prepare("DELETE FROM sessions WHERE id = ?").run(req.params.id);
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
