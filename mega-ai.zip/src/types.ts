export enum AIModel {
  FLASH_3 = "gemini-3-flash-preview",
  PRO_3 = "gemini-3-pro-preview",
  FLASH_LITE = "gemini-flash-lite-latest",
  IMAGE_2_5 = "gemini-2.5-flash-image",
  PRO_IMAGE_3 = "gemini-3-pro-image-preview",
  CHATGPT = "chatgpt-mode"
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
  model?: AIModel;
  attachments?: Attachment[];
}

export interface Attachment {
  name: string;
  type: string;
  data: string; // base64
}

export interface Session {
  id: string;
  title: string;
  created_at: number;
}

export interface AppState {
  messages: Message[];
  sessions: Session[];
  currentSessionId: string | null;
  selectedModel: AIModel;
  isGenerating: boolean;
}
