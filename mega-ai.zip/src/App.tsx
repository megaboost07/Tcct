/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Paperclip, 
  Download, 
  Github, 
  Youtube, 
  SendToBack as Telegram, 
  Code, 
  Cpu, 
  MessageSquare, 
  Plus, 
  Trash2, 
  ExternalLink,
  ChevronRight,
  Terminal,
  Layers,
  Sparkles,
  FileCode,
  X,
  Copy,
  Check,
  Star,
  Zap,
  History,
  MoreVertical,
  Edit2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { GoogleGenAI } from "@google/genai";
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { AIModel, Message, Attachment, Session } from './types';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const LOGO_URL = "https://i.supaimg.com/3f3a1c48-2002-4393-b2ec-618dcfe26b66.png";
const TELEGRAM_LINK = "https://t.me/+f8mgewlTOpM2ZTVl";
const YOUTUBE_LINK = "https://youtube.com/@kapil_h4x_live";

const MODELS = [
  { id: AIModel.CHATGPT, name: "ChatGPT", desc: "Classic GPT Experience", icon: Zap },
  { id: AIModel.FLASH_3, name: "Gemini 3 Flash", desc: "Fast & Efficient", icon: Sparkles },
  { id: AIModel.PRO_3, name: "Gemini 3 Pro", desc: "Complex Reasoning", icon: Cpu },
  { id: AIModel.FLASH_LITE, name: "Flash Lite", desc: "Lightweight", icon: Layers },
  { id: AIModel.IMAGE_2_5, name: "Gemini 2.5 Image", desc: "Visual Creation", icon: Code },
  { id: AIModel.PRO_IMAGE_3, name: "Gemini 3 Pro Image", desc: "High Quality Visuals", icon: Terminal },
];

export default function App() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [selectedModel, setSelectedModel] = useState<AIModel>(AIModel.CHATGPT);
  const [isGenerating, setIsGenerating] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showReview, setShowReview] = useState(false);
  const [rating, setRating] = useState(0);
  
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch sessions on mount
  useEffect(() => {
    fetchSessions();
  }, []);

  // Fetch messages when currentSessionId changes
  useEffect(() => {
    if (currentSessionId) {
      fetchMessages(currentSessionId);
    } else {
      setMessages([]);
    }
  }, [currentSessionId]);

  const fetchSessions = async () => {
    try {
      const res = await fetch("/api/sessions");
      const data = await res.json();
      setSessions(data);
    } catch (err) {
      console.error("Failed to fetch sessions", err);
    }
  };

  const fetchMessages = async (sessionId: string) => {
    try {
      const res = await fetch(`/api/messages/${sessionId}`);
      const data = await res.json();
      setMessages(data);
    } catch (err) {
      console.error("Failed to fetch messages", err);
    }
  };

  const createNewSession = async (title: string = "New Chat") => {
    const id = Date.now().toString();
    try {
      await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, title })
      });
      await fetchSessions();
      setCurrentSessionId(id);
    } catch (err) {
      console.error("Failed to create session", err);
    }
  };

  const deleteSession = async (id: string) => {
    try {
      await fetch(`/api/sessions/${id}`, { method: "DELETE" });
      await fetchSessions();
      if (currentSessionId === id) setCurrentSessionId(null);
    } catch (err) {
      console.error("Failed to delete session", err);
    }
  };

  const saveMessage = async (msg: Message, sessionId: string) => {
    try {
      await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...msg, session_id: sessionId })
      });
    } catch (err) {
      console.error("Failed to save message", err);
    }
  };

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        const data = base64.split(',')[1];
        setAttachments(prev => [...prev, {
          name: file.name,
          type: file.type,
          data: data
        }]);
      };
      reader.readAsDataURL(file);
    });
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const generateResponse = async (userMessage: string, currentAttachments: Attachment[], sessionId: string) => {
    setIsGenerating(true);
    
    const maxRetries = 3;
    let attempt = 0;

    const callApi = async (): Promise<string> => {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const parts: any[] = [{ text: userMessage }];
      
      currentAttachments.forEach(att => {
        parts.push({
          inlineData: {
            data: att.data,
            mimeType: att.type
          }
        });
      });

      const systemPrompt = selectedModel === AIModel.CHATGPT 
        ? "You are ChatGPT, a highly intelligent and detailed AI assistant. Provide comprehensive, step-by-step explanations and high-quality code. Be thorough and professional."
        : "You are Mega AI, a world-class coding assistant and app builder. You provide clean, professional, and production-ready code. Provide extremely detailed responses with clear explanations for every part of the code.";

      const actualModel = selectedModel === AIModel.CHATGPT ? "gemini-3-pro-preview" : selectedModel;

      const response = await ai.models.generateContent({
        model: actualModel,
        contents: { parts },
        config: {
          systemInstruction: systemPrompt,
        }
      });

      return response.text || "I'm sorry, I couldn't generate a response.";
    };

    const executeWithRetry = async (): Promise<string> => {
      try {
        return await callApi();
      } catch (error: any) {
        if (attempt < maxRetries && (error.status === 500 || error.message?.includes("Rpc failed") || error.message?.includes("xhr error"))) {
          attempt++;
          const delay = Math.pow(2, attempt) * 1000;
          console.warn(`API call failed (attempt ${attempt}). Retrying in ${delay}ms...`, error);
          await new Promise(resolve => setTimeout(resolve, delay));
          return executeWithRetry();
        }
        throw error;
      }
    };

    try {
      const aiText = await executeWithRetry();
      
      const aiMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: aiText,
        timestamp: Date.now(),
        model: selectedModel
      };

      setMessages(prev => [...prev, aiMessage]);
      await saveMessage(aiMessage, sessionId);
    } catch (error: any) {
      console.error("Error generating response after retries:", error);
      const errorMsg: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: `Error: ${error.message || "Failed to connect to AI service"}. Please try again in a few moments.`,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMsg]);
      await saveMessage(errorMsg, sessionId);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && attachments.length === 0) || isGenerating) return;

    let sessionId = currentSessionId;
    if (!sessionId) {
      const newId = Date.now().toString();
      const title = input.slice(0, 30) || "New Chat";
      await createNewSession(title);
      sessionId = newId;
    }

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: Date.now(),
      attachments: [...attachments]
    };

    setMessages(prev => [...prev, userMsg]);
    await saveMessage(userMsg, sessionId!);
    
    const currentInput = input;
    const currentAttachments = [...attachments];
    
    setInput("");
    setAttachments([]);
    
    generateResponse(currentInput, currentAttachments, sessionId!);
  };

  const copyOnlyCode = (text: string, id: string) => {
    const codeBlocks = text.match(/```[\s\S]*?```/g);
    if (!codeBlocks) {
      alert("No code blocks found to copy.");
      return;
    }
    const contentToCopy = codeBlocks.map(block => block.replace(/```\w*\n|```/g, '')).join('\n\n');
    navigator.clipboard.writeText(contentToCopy).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const downloadCode = (content: string) => {
    const codeBlocks = content.match(/```[\s\S]*?```/g);
    if (!codeBlocks) {
      alert("No code blocks found to download.");
      return;
    }

    const fullCode = codeBlocks.map(block => block.replace(/```\w*\n|```/g, '')).join('\n\n');
    const blob = new Blob([fullCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mega-ai-code-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-screen bg-zinc-50 text-zinc-900 font-sans overflow-hidden">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: sidebarOpen ? 300 : 0, opacity: sidebarOpen ? 1 : 0 }}
        className="border-r border-zinc-200 bg-white flex flex-col relative"
      >
        <div className="p-4 flex items-center justify-between border-b border-zinc-100">
          <div className="flex items-center gap-2">
            <img src={LOGO_URL} alt="Mega AI Logo" className="w-8 h-8 rounded-lg object-cover" />
            <h1 className="text-lg font-bold tracking-tight text-zinc-900">MEGA AI</h1>
          </div>
          <button 
            onClick={() => createNewSession()}
            className="p-2 hover:bg-zinc-100 rounded-lg text-zinc-600 transition-colors"
            title="New Chat"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-6">
          <div>
            <label className="text-[10px] uppercase tracking-widest text-zinc-400 font-bold mb-3 px-2 block">Chat History</label>
            <div className="space-y-1">
              {sessions.length === 0 ? (
                <div className="px-2 py-4 text-center text-xs text-zinc-400 italic">No chats yet</div>
              ) : (
                sessions.map((s) => (
                  <div 
                    key={s.id}
                    className={cn(
                      "group flex items-center gap-2 p-2 rounded-xl transition-all duration-200 cursor-pointer",
                      currentSessionId === s.id ? "bg-zinc-100 text-zinc-900" : "hover:bg-zinc-50 text-zinc-500 hover:text-zinc-900"
                    )}
                    onClick={() => setCurrentSessionId(s.id)}
                  >
                    <MessageSquare className="w-4 h-4 flex-shrink-0" />
                    <span className="text-xs font-medium truncate flex-1">{s.title}</span>
                    <button 
                      onClick={(e) => { e.stopPropagation(); deleteSession(s.id); }}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:bg-zinc-200 rounded-md transition-all"
                    >
                      <Trash2 className="w-3 h-3 text-zinc-400 hover:text-red-500" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          <div>
            <label className="text-[10px] uppercase tracking-widest text-zinc-400 font-bold mb-3 px-2 block">AI Models</label>
            <div className="space-y-1">
              {MODELS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setSelectedModel(m.id)}
                  className={cn(
                    "w-full flex items-center gap-3 p-2 rounded-xl transition-all duration-200 group text-left",
                    selectedModel === m.id 
                      ? "bg-emerald-50 text-emerald-700" 
                      : "hover:bg-zinc-50 text-zinc-500 hover:text-zinc-900"
                  )}
                >
                  <m.icon className={cn("w-4 h-4", selectedModel === m.id ? "text-emerald-600" : "text-zinc-400")} />
                  <div className="flex-1">
                    <div className="text-xs font-semibold">{m.name}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[10px] uppercase tracking-widest text-zinc-400 font-bold mb-3 px-2 block">Community</label>
            <div className="space-y-1">
              <a 
                href={TELEGRAM_LINK} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-2 rounded-xl hover:bg-zinc-50 text-zinc-500 hover:text-zinc-900 transition-colors"
              >
                <Telegram className="w-4 h-4 text-sky-500" />
                <span className="text-xs font-medium">Telegram</span>
              </a>
              <a 
                href={YOUTUBE_LINK} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-2 rounded-xl hover:bg-zinc-50 text-zinc-500 hover:text-zinc-900 transition-colors"
              >
                <Youtube className="w-4 h-4 text-red-600" />
                <span className="text-xs font-medium">YouTube</span>
              </a>
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-zinc-100">
          <button 
            onClick={() => setShowReview(true)}
            className="w-full flex items-center justify-center gap-2 p-2 rounded-xl border border-zinc-200 hover:bg-zinc-50 text-zinc-500 transition-colors text-xs font-bold"
          >
            <Star className="w-4 h-4 text-amber-500" />
            Review App
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative min-w-0 bg-white">
        {/* Header */}
        <header className="h-14 border-b border-zinc-100 flex items-center justify-between px-4 bg-white/80 backdrop-blur-md z-10">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-zinc-100 rounded-lg text-zinc-400 transition-colors"
            >
              <ChevronRight className={cn("w-5 h-5 transition-transform", sidebarOpen && "rotate-180")} />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-bold text-zinc-700">Mega AI Online</span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider hidden sm:block">
              {MODELS.find(m => m.id === selectedModel)?.name}
            </span>
            <div className="h-6 w-[1px] bg-zinc-100 mx-1" />
            <a href="https://github.com" target="_blank" rel="noopener" className="p-2 hover:bg-zinc-100 rounded-lg text-zinc-400">
              <Github className="w-4 h-4" />
            </a>
          </div>
        </header>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 scroll-smooth">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-6 max-w-2xl mx-auto">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center border border-zinc-100 shadow-lg">
                <img src={LOGO_URL} alt="Logo" className="w-10 h-10 rounded-lg" />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold text-zinc-900 tracking-tight">How can I help you today?</h2>
                <p className="text-zinc-500 text-sm">Mega AI and ChatGPT are ready to build, code, and explain.</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-lg">
                <div 
                  onClick={() => setInput("Create a React dashboard with Tailwind CSS and detailed explanations")}
                  className="p-4 bg-white border border-zinc-100 rounded-xl text-left hover:border-emerald-500/50 hover:shadow-md transition-all cursor-pointer group"
                >
                  <Code className="w-5 h-5 text-emerald-500 mb-2" />
                  <h3 className="text-xs font-bold text-zinc-900">Build an App</h3>
                  <p className="text-[10px] text-zinc-500 leading-relaxed">"Create a React dashboard with Tailwind CSS..."</p>
                </div>
                <div 
                  onClick={() => setInput("Explain this TypeScript interface and suggest detailed improvements")}
                  className="p-4 bg-white border border-zinc-100 rounded-xl text-left hover:border-sky-500/50 hover:shadow-md transition-all cursor-pointer group"
                >
                  <FileCode className="w-5 h-5 text-sky-500 mb-2" />
                  <h3 className="text-xs font-bold text-zinc-900">Analyze Code</h3>
                  <p className="text-[10px] text-zinc-500 leading-relaxed">"Explain this TypeScript interface..."</p>
                </div>
              </div>
            </div>
          ) : (
            messages.map((msg) => (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn(
                  "flex gap-4 max-w-3xl mx-auto group",
                  msg.role === "user" ? "flex-row-reverse" : "flex-row"
                )}
              >
                <div className={cn(
                  "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 border shadow-sm",
                  msg.role === "user" 
                    ? "bg-zinc-100 border-zinc-200 text-zinc-600" 
                    : "bg-emerald-50 border-emerald-100"
                )}>
                  {msg.role === "user" ? <MessageSquare className="w-4 h-4" /> : <img src={LOGO_URL} className="w-5 h-5 rounded-md" />}
                </div>
                
                <div className={cn(
                  "flex flex-col gap-2 max-w-[85%]",
                  msg.role === "user" ? "items-end" : "items-start"
                )}>
                  <div className={cn(
                    "p-4 rounded-2xl text-sm leading-relaxed",
                    msg.role === "user" 
                      ? "bg-emerald-600 text-white shadow-md shadow-emerald-100" 
                      : "bg-white text-zinc-800"
                  )}>
                    {msg.attachments && msg.attachments.length > 0 && (
                      <div className="flex flex-wrap gap-2 mb-3">
                        {msg.attachments.map((att, i) => (
                          <div key={i} className="flex items-center gap-2 px-2 py-1 bg-zinc-50 rounded-lg text-[10px] font-bold border border-zinc-200 text-zinc-600">
                            <Paperclip className="w-3 h-3" />
                            {att.name}
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="prose prose-sm max-w-none prose-zinc">
                      <Markdown>{msg.content}</Markdown>
                    </div>
                  </div>
                  
                  {msg.role === "assistant" && (
                    <div className="flex items-center gap-4 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => copyOnlyCode(msg.content, msg.id)}
                        className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-zinc-400 hover:text-emerald-600 transition-colors"
                      >
                        {copiedId === msg.id ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                        {copiedId === msg.id ? "Copied Code!" : "Copy Only Code"}
                      </button>
                      <button 
                        onClick={() => downloadCode(msg.content)}
                        className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-zinc-400 hover:text-emerald-600 transition-colors"
                      >
                        <Download className="w-3 h-3" />
                        Download
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            ))
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-gradient-to-t from-white via-white to-transparent">
          <div className="max-w-3xl mx-auto relative">
            <AnimatePresence>
              {attachments.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute bottom-full left-0 right-0 mb-4 flex flex-wrap gap-2 p-3 bg-white border border-zinc-100 rounded-2xl shadow-xl"
                >
                  {attachments.map((att, i) => (
                    <div key={i} className="flex items-center gap-2 px-2 py-1.5 bg-zinc-50 rounded-xl text-[10px] font-bold border border-zinc-100 group">
                      <Paperclip className="w-3 h-3 text-emerald-500" />
                      <span className="max-w-[120px] truncate text-zinc-600">{att.name}</span>
                      <button onClick={() => removeAttachment(i)} className="p-1 hover:bg-zinc-200 rounded-full transition-colors">
                        <X className="w-3 h-3 text-zinc-400" />
                      </button>
                    </div>
                  ))}
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 px-2 py-1.5 bg-emerald-50 text-emerald-600 rounded-xl text-[10px] font-bold border border-emerald-100 hover:bg-emerald-100 transition-colors"
                  >
                    <Plus className="w-3 h-3" />
                    Add More
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            <form 
              onSubmit={handleSubmit}
              className="relative group bg-white border border-zinc-200 rounded-2xl focus-within:border-zinc-300 focus-within:shadow-md transition-all"
            >
              <div className="flex items-end px-3 py-3">
                <button 
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 hover:bg-zinc-50 rounded-xl text-zinc-400 hover:text-emerald-500 transition-all mb-0.5"
                >
                  <Paperclip className="w-5 h-5" />
                </button>
                <textarea 
                  rows={1}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSubmit(e as any);
                    }
                  }}
                  placeholder={isGenerating ? "Mega AI is thinking..." : "Message Mega AI..."}
                  disabled={isGenerating}
                  className="flex-1 bg-transparent border-none focus:ring-0 text-sm text-zinc-900 placeholder-zinc-400 px-3 py-2 resize-none max-h-48 overflow-y-auto"
                />
                <button 
                  type="submit"
                  disabled={(!input.trim() && attachments.length === 0) || isGenerating}
                  className={cn(
                    "p-2 rounded-xl transition-all mb-0.5",
                    (!input.trim() && attachments.length === 0) || isGenerating
                      ? "text-zinc-300 bg-zinc-50 cursor-not-allowed"
                      : "text-white bg-zinc-900 hover:bg-zinc-800 shadow-md"
                  )}
                >
                  {isGenerating ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                </button>
              </div>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                multiple 
                className="hidden" 
              />
            </form>
            <p className="text-[9px] text-center text-zinc-400 mt-3 uppercase tracking-widest font-bold">
              Mega AI can make mistakes. Check important info.
            </p>
          </div>
        </div>
      </main>

      {/* Review Modal */}
      <AnimatePresence>
        {showReview && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl space-y-6"
            >
              <div className="text-center space-y-2">
                <h3 className="text-2xl font-bold text-zinc-900">Enjoying Mega AI?</h3>
                <p className="text-zinc-500">Your feedback helps us build better tools for you.</p>
              </div>
              
              <div className="flex justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button 
                    key={star}
                    onClick={() => setRating(star)}
                    className="p-2 transition-transform hover:scale-110"
                  >
                    <Star className={cn("w-10 h-10", rating >= star ? "text-amber-400 fill-amber-400" : "text-zinc-200")} />
                  </button>
                ))}
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => setShowReview(false)}
                  className="flex-1 p-3 rounded-xl border border-zinc-200 text-zinc-500 font-bold hover:bg-zinc-50 transition-colors"
                >
                  Maybe Later
                </button>
                <button 
                  onClick={() => {
                    alert("Thank you for your review!");
                    setShowReview(false);
                  }}
                  className="flex-1 p-3 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 transition-colors shadow-lg shadow-emerald-200"
                >
                  Submit Review
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
